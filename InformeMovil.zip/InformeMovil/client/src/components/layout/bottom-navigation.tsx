import { cn } from '@/lib/utils';
import { BarChart3, FileText, Plus, User } from 'lucide-react';
import { Link, useLocation } from 'wouter';

const navItems = [
  { id: 'dashboard', icon: BarChart3, label: 'Dashboard', path: '/' },
  { id: 'reports', icon: FileText, label: 'Reports', path: '/reports' },
  { id: 'create', icon: Plus, label: 'Create', path: '/create' },
  { id: 'profile', icon: User, label: 'Profile', path: '/profile' },
];

export function BottomNavigation() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-sm bg-card border-t border-border">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <Link key={item.id} href={item.path}>
              <button
                className={cn(
                  'flex flex-col items-center p-3 transition-colors',
                  isActive 
                    ? 'text-primary' 
                    : 'text-muted-foreground hover:text-primary'
                )}
                data-testid={`nav-${item.id}`}
              >
                <Icon className="w-5 h-5 mb-1" />
                <span className="text-xs">{item.label}</span>
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
