import { useEffect, forwardRef } from 'react';
import { cn } from '@/lib/utils';
import { useSignature } from '@/hooks/useSignature';
import { Button } from './button';

interface SignaturePadProps {
  onSignatureChange?: (signature: { dataUrl: string; timestamp: string; signerName: string } | null) => void;
  signerName?: string;
  className?: string;
  disabled?: boolean;
}

export const SignaturePad = forwardRef<HTMLCanvasElement, SignaturePadProps>(
  ({ onSignatureChange, signerName = '', className, disabled = false }, ref) => {
    const {
      canvasRef,
      startDrawing,
      draw,
      stopDrawing,
      clearSignature,
      getSignatureData,
      initializeCanvas,
    } = useSignature();

    useEffect(() => {
      initializeCanvas();
    }, [initializeCanvas]);

    const handleClear = () => {
      clearSignature();
      onSignatureChange?.(null);
    };

    const handleSignatureComplete = () => {
      if (signerName) {
        const signatureData = getSignatureData(signerName);
        onSignatureChange?.(signatureData);
      }
    };

    return (
      <div className={cn('space-y-2', className)}>
        <div className="border-2 border-dashed border-border rounded-lg bg-muted/50 p-4">
          <canvas
            ref={(element) => {
              if (typeof ref === 'function') {
                ref(element);
              } else if (ref) {
                ref.current = element;
              }
              if (canvasRef) {
                canvasRef.current = element;
              }
            }}
            width={300}
            height={150}
            className="w-full h-32 cursor-crosshair touch-none"
            onMouseDown={disabled ? undefined : startDrawing}
            onMouseMove={disabled ? undefined : draw}
            onMouseUp={disabled ? undefined : () => {
              stopDrawing();
              handleSignatureComplete();
            }}
            onMouseLeave={disabled ? undefined : stopDrawing}
            onTouchStart={disabled ? undefined : (e) => {
              e.preventDefault();
              startDrawing(e);
            }}
            onTouchMove={disabled ? undefined : (e) => {
              e.preventDefault();
              draw(e);
            }}
            onTouchEnd={disabled ? undefined : (e) => {
              e.preventDefault();
              stopDrawing();
              handleSignatureComplete();
            }}
            data-testid="signature-canvas"
          />
        </div>
        <div className="flex justify-between">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleClear}
            disabled={disabled}
            data-testid="button-clear-signature"
          >
            Clear
          </Button>
          <span className="text-sm text-muted-foreground">
            Sign above
          </span>
        </div>
      </div>
    );
  }
);

SignaturePad.displayName = 'SignaturePad';
