import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import type { User } from '@shared/schema';

// Demo users for testing
const DEMO_USERS: Record<string, User & { password: string }> = {
  'admin@reportpro.com': {
    id: 'admin-001',
    email: 'admin@reportpro.com',
    firstName: 'Admin',
    lastName: 'User',
    role: 'admin',
    firebaseUid: 'admin-001',
    createdAt: new Date('2024-01-01').toISOString(),
    password: 'admin123'
  },
  'user@reportpro.com': {
    id: 'user-001', 
    email: 'user@reportpro.com',
    firstName: 'Demo',
    lastName: 'User',
    role: 'user',
    firebaseUid: 'user-001',
    createdAt: new Date('2024-01-01').toISOString(),
    password: 'user123'
  }
};

interface AuthContextType {
  user: User | null;
  firebaseUser: any;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, firstName: string, lastName: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('demo_user');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      setUser(userData);
      setFirebaseUser({ uid: userData.id });
    }
    setLoading(false);
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      const demoUser = DEMO_USERS[email.toLowerCase()];
      if (!demoUser || demoUser.password !== password) {
        throw new Error('Invalid email or password');
      }
      
      const { password: _, ...userWithoutPassword } = demoUser;
      setUser(userWithoutPassword);
      setFirebaseUser({ uid: demoUser.id });
      localStorage.setItem('demo_user', JSON.stringify(userWithoutPassword));
    } catch (error) {
      console.error('Sign in error:', error);
      throw error;
    }
  };

  const signUp = async (email: string, password: string, firstName: string, lastName: string) => {
    try {
      if (DEMO_USERS[email.toLowerCase()]) {
        throw new Error('Email already exists');
      }
      
      const userId = `user-${Date.now()}`;
      const newUser: User = {
        id: userId,
        email,
        firstName,
        lastName,
        role: 'user',
        firebaseUid: userId,
        createdAt: new Date().toISOString(),
      };
      
      setUser(newUser);
      setFirebaseUser({ uid: userId });
      localStorage.setItem('demo_user', JSON.stringify(newUser));
      
      // Store in demo users for future logins
      DEMO_USERS[email.toLowerCase()] = { ...newUser, password };
    } catch (error) {
      console.error('Sign up error:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      setUser(null);
      setFirebaseUser(null);
      localStorage.removeItem('demo_user');
    } catch (error) {
      console.error('Logout error:', error);
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ user, firebaseUser, loading, signIn, signUp, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
