import type { Report } from '@shared/schema';

// Mock data storage
let mockReports: Report[] = [
  {
    id: 'report-001',
    title: 'Inspección de Seguridad - Área de Almacén',
    description: 'Inspección rutinaria de seguridad en el área de almacén. Se encontraron algunas señalizaciones que necesitan renovación y se verificó el correcto funcionamiento de los equipos de emergencia.',
    category: 'safety',
    location: 'Almacén Principal, Planta 1',
    priority: 'medium',
    status: 'completed',
    reportDate: '2024-12-01T14:30:00.000Z',
    images: [],
    signature: {
      dataUrl: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="150" viewBox="0 0 300 150"><path d="M50 100 Q 150 50 250 100" stroke="black" stroke-width="2" fill="none"/><text x="150" y="130" text-anchor="middle" font-family="serif" font-size="12">Admin User</text></svg>',
      timestamp: '2024-12-01T14:30:00.000Z',
      signerName: 'Admin User'
    },
    authorId: 'admin-001',
    createdAt: '2024-12-01T14:30:00.000Z',
    updatedAt: '2024-12-01T14:30:00.000Z',
  },
  {
    id: 'report-002',
    title: 'Mantenimiento Preventivo - Equipos HVAC',
    description: 'Mantenimiento programado de sistemas de aire acondicionado y ventilación. Se realizó limpieza de filtros, verificación de niveles de refrigerante y pruebas de funcionamiento.',
    category: 'maintenance',
    location: 'Edificio A, Todas las plantas',
    priority: 'high',
    status: 'pending',
    reportDate: '2024-12-05T09:00:00.000Z',
    images: [],
    signature: {
      dataUrl: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="150" viewBox="0 0 300 150"><path d="M60 80 L 90 60 L 120 90 L 150 70 L 180 85 L 210 75 L 240 95" stroke="black" stroke-width="2" fill="none"/><text x="150" y="130" text-anchor="middle" font-family="serif" font-size="12">Demo User</text></svg>',
      timestamp: '2024-12-05T09:00:00.000Z',
      signerName: 'Demo User'
    },
    authorId: 'user-001',
    createdAt: '2024-12-05T09:00:00.000Z',
    updatedAt: '2024-12-05T09:00:00.000Z',
  },
  {
    id: 'report-003',
    title: 'Incidente Menor - Derrame en Laboratorio',
    description: 'Se reportó un pequeño derrame de líquido no tóxico en el laboratorio 3. Se procedió inmediatamente con el protocolo de limpieza y se verificó que no hubo contaminación del área circundante.',
    category: 'incident',
    location: 'Laboratorio 3, Planta 2',
    priority: 'low',
    status: 'completed',
    reportDate: '2024-12-03T16:45:00.000Z',
    images: [],
    authorId: 'admin-001',
    createdAt: '2024-12-03T16:45:00.000Z',
    updatedAt: '2024-12-03T16:45:00.000Z',
  },
  {
    id: 'report-004',
    title: 'Inspección Eléctrica - Panel Principal',
    description: 'Inspección trimestral del panel eléctrico principal. Todos los sistemas funcionando correctamente, se registraron las lecturas de voltaje y amperaje dentro de parámetros normales.',
    category: 'inspection',
    location: 'Cuarto Eléctrico, Sótano',
    priority: 'medium',
    status: 'draft',
    reportDate: '2024-12-07T11:15:00.000Z',
    images: [],
    authorId: 'user-001',
    createdAt: '2024-12-07T11:15:00.000Z',
    updatedAt: '2024-12-07T11:15:00.000Z',
  }
];

// Load reports from localStorage or use mock data
const STORAGE_KEY = 'reportpro_reports';

function loadReports(): Report[] {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) {
    return JSON.parse(stored);
  }
  // Save mock data to localStorage first time
  saveReports(mockReports);
  return mockReports;
}

function saveReports(reports: Report[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
  mockReports = reports;
}

// Mock Firebase Firestore functions
export const mockFirestore = {
  // Get all reports for a user
  getReports: async (authorId: string): Promise<Report[]> => {
    const reports = loadReports();
    return reports.filter(report => report.authorId === authorId);
  },

  // Get a single report
  getReport: async (id: string): Promise<Report | null> => {
    const reports = loadReports();
    return reports.find(report => report.id === id) || null;
  },

  // Add a new report
  addReport: async (report: Omit<Report, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> => {
    const reports = loadReports();
    const newReport: Report = {
      ...report,
      id: `report-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(newReport);
    saveReports(reports);
    return newReport.id;
  },

  // Update a report
  updateReport: async (id: string, updates: Partial<Report>): Promise<void> => {
    const reports = loadReports();
    const index = reports.findIndex(report => report.id === id);
    if (index !== -1) {
      reports[index] = {
        ...reports[index],
        ...updates,
        updatedAt: new Date().toISOString(),
      };
      saveReports(reports);
    }
  },

  // Delete a report
  deleteReport: async (id: string): Promise<void> => {
    const reports = loadReports();
    const filtered = reports.filter(report => report.id !== id);
    saveReports(filtered);
  }
};

// Mock Firebase Storage functions
export const mockStorage = {
  uploadFile: async (file: File, path: string): Promise<string> => {
    // Simulate upload by creating a data URL
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => {
        // In a real app, this would be a Firebase Storage URL
        resolve(reader.result as string);
      };
      reader.readAsDataURL(file);
    });
  }
};