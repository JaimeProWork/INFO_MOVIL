import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { mockFirestore, mockStorage } from '@/lib/mockFirebase';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { MobileHeader } from '@/components/layout/mobile-header';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { SignaturePad } from '@/components/ui/signature-pad';
import { Camera, X, MapPin, Save, Send } from 'lucide-react';
import { useLocation } from 'wouter';
import { insertReportSchema } from '@shared/schema';
import { z } from 'zod';

const formSchema = insertReportSchema.extend({
  reportDate: z.string().min(1, 'Date and time is required'),
});

type FormData = z.infer<typeof formSchema>;

export default function CreateReportPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [uploading, setUploading] = useState(false);
  const [images, setImages] = useState<File[]>([]);
  const [signature, setSignature] = useState<{ dataUrl: string; timestamp: string; signerName: string } | null>(null);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: '',
      description: '',
      category: '',
      location: '',
      priority: 'medium',
      status: 'draft',
      reportDate: new Date().toISOString().slice(0, 16),
    },
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (images.length + files.length > 5) {
      toast({
        variant: 'destructive',
        title: 'Too many images',
        description: 'Maximum 5 images allowed',
      });
      return;
    }

    // Check file sizes (max 10MB each)
    const oversizedFiles = files.filter(file => file.size > 10 * 1024 * 1024);
    if (oversizedFiles.length > 0) {
      toast({
        variant: 'destructive',
        title: 'File too large',
        description: 'Each image must be under 10MB',
      });
      return;
    }

    setImages(prev => [...prev, ...files]);
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const uploadImages = async (): Promise<string[]> => {
    if (images.length === 0) return [];

    const uploadPromises = images.map(async (image, index) => {
      const path = `reports/${user?.id}/${Date.now()}_${index}_${image.name}`;
      return mockStorage.uploadFile(image, path);
    });

    return Promise.all(uploadPromises);
  };

  const onSubmit = async (data: FormData, isDraft = false) => {
    if (!user) return;

    if (!isDraft && !signature) {
      toast({
        variant: 'destructive',
        title: 'Signature required',
        description: 'Please provide your digital signature before submitting',
      });
      return;
    }

    setUploading(true);

    try {
      // Upload images
      const imageUrls = await uploadImages();

      // Prepare report data
      const reportData = {
        ...data,
        authorId: user.id,
        status: isDraft ? 'draft' : 'pending',
        images: imageUrls,
        signature: signature,
        reportDate: new Date(data.reportDate).toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      // Save to mock storage
      await mockFirestore.addReport(reportData);

      toast({
        title: isDraft ? 'Draft saved' : 'Report submitted',
        description: isDraft 
          ? 'Your report has been saved as a draft'
          : 'Your report has been submitted successfully',
      });

      // Navigate to reports page
      setLocation('/reports');
    } catch (error) {
      console.error('Error saving report:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to save report. Please try again.',
      });
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = (isDraft = false) => {
    return form.handleSubmit((data) => onSubmit(data, isDraft));
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <MobileHeader title="Create Report" />
      
      <main className="p-4">
        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold text-foreground mb-6">Create New Report</h2>
            
            <form className="space-y-6">
              {/* Basic Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-foreground">Basic Information</h3>
                
                <div>
                  <Label htmlFor="title">Report Title *</Label>
                  <Input
                    id="title"
                    placeholder="Enter report title..."
                    {...form.register('title')}
                    data-testid="input-title"
                  />
                  {form.formState.errors.title && (
                    <p className="text-sm text-destructive mt-1">{form.formState.errors.title.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="category">Category *</Label>
                  <Select value={form.watch('category')} onValueChange={(value) => form.setValue('category', value)}>
                    <SelectTrigger data-testid="select-category">
                      <SelectValue placeholder="Select category..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="safety">Safety</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="inspection">Inspection</SelectItem>
                      <SelectItem value="incident">Incident</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.category && (
                    <p className="text-sm text-destructive mt-1">{form.formState.errors.category.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="location">Location *</Label>
                  <div className="relative">
                    <Input
                      id="location"
                      placeholder="Enter location..."
                      {...form.register('location')}
                      className="pr-10"
                      data-testid="input-location"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-full"
                      data-testid="button-location"
                    >
                      <MapPin className="w-4 h-4" />
                    </Button>
                  </div>
                  {form.formState.errors.location && (
                    <p className="text-sm text-destructive mt-1">{form.formState.errors.location.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="reportDate">Date & Time *</Label>
                  <Input
                    id="reportDate"
                    type="datetime-local"
                    {...form.register('reportDate')}
                    data-testid="input-datetime"
                  />
                  {form.formState.errors.reportDate && (
                    <p className="text-sm text-destructive mt-1">{form.formState.errors.reportDate.message}</p>
                  )}
                </div>
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  rows={4}
                  placeholder="Provide detailed description..."
                  {...form.register('description')}
                  data-testid="textarea-description"
                />
                {form.formState.errors.description && (
                  <p className="text-sm text-destructive mt-1">{form.formState.errors.description.message}</p>
                )}
              </div>

              {/* Images Section */}
              <div>
                <Label>Attach Images</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary transition-colors">
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                    data-testid="input-images"
                  />
                  <label htmlFor="image-upload" className="cursor-pointer">
                    <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto mb-3">
                      <Camera className="w-6 h-6 text-muted-foreground" />
                    </div>
                    <p className="text-muted-foreground mb-2">Tap to add photos</p>
                    <p className="text-xs text-muted-foreground">Max 5 images, 10MB each</p>
                  </label>
                </div>
                
                {/* Preview uploaded images */}
                {images.length > 0 && (
                  <div className="mt-3 grid grid-cols-3 gap-2">
                    {images.map((image, index) => (
                      <div key={index} className="relative aspect-square bg-muted rounded-lg overflow-hidden">
                        <img
                          src={URL.createObjectURL(image)}
                          alt={`Upload ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-1 right-1 w-6 h-6"
                          onClick={() => removeImage(index)}
                          data-testid={`button-remove-image-${index}`}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Digital Signature */}
              <div>
                <Label>Digital Signature *</Label>
                <SignaturePad
                  onSignatureChange={setSignature}
                  signerName={`${user?.firstName} ${user?.lastName}`}
                />
                {!signature && form.formState.isSubmitted && (
                  <p className="text-sm text-destructive mt-1">Digital signature is required</p>
                )}
              </div>

              {/* Priority */}
              <div>
                <Label>Priority Level</Label>
                <RadioGroup
                  value={form.watch('priority')}
                  onValueChange={(value) => form.setValue('priority', value as 'low' | 'medium' | 'high')}
                  className="flex space-x-6 mt-2"
                  data-testid="radio-priority"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="low" id="low" />
                    <Label htmlFor="low">Low</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="medium" id="medium" />
                    <Label htmlFor="medium">Medium</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="high" id="high" />
                    <Label htmlFor="high">High</Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={handleSubmit(true)}
                  disabled={uploading}
                  data-testid="button-save-draft"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {uploading ? 'Saving...' : 'Save as Draft'}
                </Button>
                <Button
                  type="button"
                  className="flex-1"
                  onClick={handleSubmit(false)}
                  disabled={uploading}
                  data-testid="button-submit-report"
                >
                  <Send className="w-4 h-4 mr-2" />
                  {uploading ? 'Submitting...' : 'Submit Report'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
