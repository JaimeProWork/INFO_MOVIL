import { useAuth } from '@/hooks/useAuth';
import { MobileHeader } from '@/components/layout/mobile-header';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  User, 
  Bell, 
  Download, 
  Cloud, 
  Shield, 
  Lock, 
  HelpCircle, 
  Info, 
  LogOut,
  ChevronRight 
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useState, useEffect } from 'react';
import { mockFirestore } from '@/lib/mockFirebase';

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [stats, setStats] = useState({
    totalReports: 0,
    monthlyReports: 0,
  });

  useEffect(() => {
    loadUserStats();
  }, [user]);

  const loadUserStats = async () => {
    if (!user) return;

    try {
      const reports = await mockFirestore.getReports(user.id);
      const now = new Date();
      const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      
      setStats({
        totalReports: reports.length,
        monthlyReports: reports.filter(r => new Date(r.createdAt) >= thisMonth).length,
      });
    } catch (error) {
      console.error('Error loading user stats:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: 'Logged out',
        description: 'You have been successfully logged out.',
      });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to logout. Please try again.',
      });
    }
  };

  const handleMenuAction = (action: string) => {
    toast({
      title: 'Feature Coming Soon',
      description: `${action} functionality will be available in a future update.`,
    });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <MobileHeader title="Profile" />
        <div className="p-4 text-center">
          <p>Please log in to view your profile.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <MobileHeader title="Profile" />
      
      <main className="p-4 space-y-4">
        {/* Profile Header */}
        <Card>
          <CardContent className="p-4 text-center">
            <Avatar className="w-20 h-20 mx-auto mb-3">
              <AvatarFallback className="text-2xl font-semibold">
                {user.firstName[0]}{user.lastName[0]}
              </AvatarFallback>
            </Avatar>
            <h2 className="text-xl font-semibold text-foreground" data-testid="profile-name">
              {user.firstName} {user.lastName}
            </h2>
            <p className="text-muted-foreground" data-testid="profile-email">
              {user.email}
            </p>
            <div className="flex items-center justify-center space-x-8 mt-4 text-sm text-muted-foreground">
              <div className="text-center">
                <div className="font-semibold text-foreground text-lg" data-testid="stat-total">
                  {stats.totalReports}
                </div>
                <div>Reports</div>
              </div>
              <div className="text-center">
                <div className="font-semibold text-foreground text-lg" data-testid="stat-monthly">
                  {stats.monthlyReports}
                </div>
                <div>This Month</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Settings Menu */}
        <Card>
          <CardContent className="p-1">
            <Button
              variant="ghost"
              className="w-full justify-between p-3 h-auto"
              onClick={() => handleMenuAction('Edit Profile')}
              data-testid="button-edit-profile"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <User className="w-4 h-4 text-primary" />
                </div>
                <span className="font-medium">Edit Profile</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-1 space-y-1">
            <Button
              variant="ghost"
              className="w-full justify-between p-3 h-auto"
              onClick={() => handleMenuAction('Notifications')}
              data-testid="button-notifications"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <Bell className="w-4 h-4 text-secondary" />
                </div>
                <span className="font-medium">Notifications</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </Button>
            
            <Button
              variant="ghost"
              className="w-full justify-between p-3 h-auto"
              onClick={() => handleMenuAction('Export Data')}
              data-testid="button-export-data"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Download className="w-4 h-4 text-primary" />
                </div>
                <span className="font-medium">Export Data</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </Button>

            <Button
              variant="ghost"
              className="w-full justify-between p-3 h-auto"
              onClick={() => handleMenuAction('Backup & Sync')}
              data-testid="button-backup"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <Cloud className="w-4 h-4 text-secondary" />
                </div>
                <span className="font-medium">Backup & Sync</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-1 space-y-1">
            <Button
              variant="ghost"
              className="w-full justify-between p-3 h-auto"
              onClick={() => handleMenuAction('Security')}
              data-testid="button-security"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Shield className="w-4 h-4 text-primary" />
                </div>
                <span className="font-medium">Security</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </Button>

            <Button
              variant="ghost"
              className="w-full justify-between p-3 h-auto"
              onClick={() => handleMenuAction('Privacy')}
              data-testid="button-privacy"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <Lock className="w-4 h-4 text-secondary" />
                </div>
                <span className="font-medium">Privacy</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-1 space-y-1">
            <Button
              variant="ghost"
              className="w-full justify-between p-3 h-auto"
              onClick={() => handleMenuAction('Help & Support')}
              data-testid="button-help"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <HelpCircle className="w-4 h-4 text-primary" />
                </div>
                <span className="font-medium">Help & Support</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </Button>

            <Button
              variant="ghost"
              className="w-full justify-between p-3 h-auto"
              onClick={() => handleMenuAction('About')}
              data-testid="button-about"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <Info className="w-4 h-4 text-secondary" />
                </div>
                <span className="font-medium">About</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </Button>
          </CardContent>
        </Card>

        {/* Logout */}
        <Card>
          <CardContent className="p-1">
            <Button
              variant="ghost"
              className="w-full justify-between p-3 h-auto text-destructive hover:text-destructive"
              onClick={handleLogout}
              data-testid="button-logout"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-destructive/10 rounded-lg flex items-center justify-center">
                  <LogOut className="w-4 h-4 text-destructive" />
                </div>
                <span className="font-medium">Logout</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </Button>
          </CardContent>
        </Card>

        {/* App Version */}
        <div className="text-center text-sm text-muted-foreground py-4">
          ReportPro v1.0.0
        </div>
      </main>
    </div>
  );
}
