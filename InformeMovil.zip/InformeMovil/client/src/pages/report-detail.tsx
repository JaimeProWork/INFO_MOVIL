import { useEffect, useState } from 'react';
import { mockFirestore } from '@/lib/mockFirebase';
import { useAuth } from '@/hooks/useAuth';
import { MobileHeader } from '@/components/layout/mobile-header';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ArrowLeft, Share, Download, FileText, MapPin, MoreVertical, Mail } from 'lucide-react';
import { FaWhatsapp } from 'react-icons/fa';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import type { Report, User } from '@shared/schema';
import jsPDF from 'jspdf';

interface ReportDetailPageProps {
  params: { id: string };
}

export default function ReportDetailPage({ params }: ReportDetailPageProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [report, setReport] = useState<Report | null>(null);
  const [author, setAuthor] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReport();
  }, [params.id]);

  const loadReport = async () => {
    try {
      const reportData = await mockFirestore.getReport(params.id);
      
      if (!reportData) {
        toast({
          variant: 'destructive',
          title: 'Report not found',
          description: 'The requested report could not be found.',
        });
        setLocation('/reports');
        return;
      }

      setReport(reportData);

      // Mock author info (in real app would load from user collection)
      const mockAuthor: User = {
        id: reportData.authorId,
        email: reportData.authorId === 'admin-001' ? 'admin@reportpro.com' : 'user@reportpro.com',
        firstName: reportData.authorId === 'admin-001' ? 'Admin' : 'Demo',
        lastName: 'User',
        role: reportData.authorId === 'admin-001' ? 'admin' : 'user',
        firebaseUid: reportData.authorId,
        createdAt: new Date().toISOString(),
      };
      setAuthor(mockAuthor);
    } catch (error) {
      console.error('Error loading report:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to load report details.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    setLocation('/reports');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: report?.title,
        text: report?.description,
        url: window.location.href,
      });
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: 'Link copied',
        description: 'Report link has been copied to clipboard.',
      });
    }
  };

  const handleExportPDF = () => {
    if (!report || !author) return;

    const pdf = new jsPDF();
    const pageHeight = pdf.internal.pageSize.height;
    let y = 20;

    // Title
    pdf.setFontSize(20);
    pdf.text(report.title, 20, y);
    y += 15;

    // Report info
    pdf.setFontSize(12);
    pdf.text(`Category: ${report.category.charAt(0).toUpperCase() + report.category.slice(1)}`, 20, y);
    y += 10;
    pdf.text(`Location: ${report.location}`, 20, y);
    y += 10;
    pdf.text(`Date: ${new Date(report.reportDate).toLocaleDateString()}`, 20, y);
    y += 10;
    pdf.text(`Status: ${report.status.charAt(0).toUpperCase() + report.status.slice(1)}`, 20, y);
    y += 10;
    pdf.text(`Priority: ${report.priority.charAt(0).toUpperCase() + report.priority.slice(1)}`, 20, y);
    y += 15;

    // Description
    pdf.text('Description:', 20, y);
    y += 10;
    const splitDescription = pdf.splitTextToSize(report.description, 170);
    pdf.text(splitDescription, 20, y);
    y += splitDescription.length * 7 + 10;

    // Author signature
    if (report.signature) {
      y += 20;
      pdf.text('Digital Signature:', 20, y);
      y += 10;
      pdf.text(`Signed by: ${report.signature.signerName}`, 20, y);
      y += 10;
      pdf.text(`Date: ${new Date(report.signature.timestamp).toLocaleString()}`, 20, y);
    }

    // Save the PDF
    pdf.save(`${report.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.pdf`);
    
    toast({
      title: 'PDF exported',
      description: 'Report has been exported as PDF.',
    });
  };

  const handleWhatsAppShare = () => {
    if (!report) return;
    
    const message = encodeURIComponent(
      `Report: ${report.title}\n\nCategory: ${report.category}\nLocation: ${report.location}\nStatus: ${report.status}\n\nDescription: ${report.description}`
    );
    window.open(`https://wa.me/?text=${message}`, '_blank');
  };

  const handleEmailShare = () => {
    if (!report) return;
    
    const subject = encodeURIComponent(`Report: ${report.title}`);
    const body = encodeURIComponent(
      `Report Details:\n\nTitle: ${report.title}\nCategory: ${report.category}\nLocation: ${report.location}\nStatus: ${report.status}\nDate: ${new Date(report.reportDate).toLocaleString()}\n\nDescription:\n${report.description}`
    );
    window.open(`mailto:?subject=${subject}&body=${body}`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-secondary/10 text-secondary';
      case 'pending':
        return 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400';
      case 'urgent':
        return 'bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-400';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <MobileHeader title="Report Details" />
        <div className="p-4">
          <div className="animate-pulse space-y-4">
            <div className="h-40 bg-muted rounded-lg"></div>
            <div className="h-32 bg-muted rounded-lg"></div>
            <div className="h-24 bg-muted rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!report) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <MobileHeader title="Report Not Found" />
        <div className="p-4 text-center">
          <FileText className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
          <h3 className="text-lg font-semibold mb-2">Report not found</h3>
          <p className="text-muted-foreground mb-4">The requested report could not be found.</p>
          <Button onClick={handleBack}>Back to Reports</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="p-4 space-y-4">
        {/* Header Actions */}
        <div className="flex items-center justify-between mb-4">
          <Button variant="ghost" size="icon" onClick={handleBack} data-testid="button-back">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" onClick={handleShare} data-testid="button-share">
              <Share className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={handleExportPDF} data-testid="button-export-pdf">
              <Download className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" data-testid="button-more">
              <MoreVertical className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Report Details */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h1 className="text-xl font-semibold text-foreground mb-2" data-testid="report-title">
                  {report.title}
                </h1>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(report.category)}`}>
                    {report.category.charAt(0).toUpperCase() + report.category.slice(1)}
                  </span>
                  <span>{new Date(report.reportDate).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}</span>
                </div>
              </div>
              <span className={`px-3 py-1 text-sm rounded-full font-medium ${getStatusColor(report.status)}`}>
                {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
              </span>
            </div>

            {/* Author and Location */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <span className="text-sm text-muted-foreground">Reporter</span>
                <div className="flex items-center space-x-2 mt-1">
                  <Avatar className="w-6 h-6">
                    <AvatarFallback className="text-xs">
                      {author ? `${author.firstName[0]}${author.lastName[0]}` : 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium">
                    {author ? `${author.firstName} ${author.lastName}` : 'Unknown'}
                  </span>
                </div>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Location</span>
                <div className="flex items-center space-x-1 mt-1">
                  <MapPin className="w-3 h-3 text-muted-foreground" />
                  <span className="text-sm">{report.location}</span>
                </div>
              </div>
            </div>

            {/* Priority */}
            <div className="mb-4">
              <span className="text-sm text-muted-foreground">Priority</span>
              <div className={`inline-block px-2 py-1 text-xs rounded-full ml-2 ${
                report.priority === 'high' ? 'bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-400' :
                report.priority === 'medium' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400' :
                'bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400'
              }`}>
                {report.priority.charAt(0).toUpperCase() + report.priority.slice(1)}
              </div>
            </div>

            {/* Description */}
            <div className="mb-4">
              <h3 className="font-medium text-foreground mb-2">Description</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {report.description}
              </p>
            </div>

            {/* Images */}
            {report.images && report.images.length > 0 && (
              <div className="mb-4">
                <h3 className="font-medium text-foreground mb-3">
                  Attached Images ({report.images.length})
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {report.images.map((imageUrl, index) => (
                    <div
                      key={index}
                      className="aspect-square rounded-lg overflow-hidden cursor-pointer hover:opacity-80 transition-opacity"
                      onClick={() => window.open(imageUrl, '_blank')}
                    >
                      <img
                        src={imageUrl}
                        alt={`Report image ${index + 1}`}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><rect width="100" height="100" fill="%23f3f4f6"/><text x="50" y="50" text-anchor="middle" dy="0.3em" font-family="sans-serif" font-size="12" fill="%236b7280">Image</text></svg>';
                        }}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Digital Signature */}
            {report.signature && (
              <div className="mb-4">
                <h3 className="font-medium text-foreground mb-3">Digital Signature</h3>
                <div className="border border-border rounded-lg p-4 bg-muted/50">
                  <div className="h-20 flex items-center justify-center mb-2">
                    <img
                      src={report.signature.dataUrl}
                      alt="Digital signature"
                      className="max-h-full max-w-full"
                    />
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">{report.signature.signerName}</div>
                    <div className="text-xs text-muted-foreground">
                      Signed on {new Date(report.signature.timestamp).toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="space-y-3">
          <Button
            className="w-full"
            onClick={handleExportPDF}
            data-testid="button-export-pdf-main"
          >
            <FileText className="w-4 h-4 mr-2" />
            Export as PDF
          </Button>
          
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              onClick={handleWhatsAppShare}
              className="bg-green-500 hover:bg-green-600 text-white border-green-500"
              data-testid="button-share-whatsapp"
            >
              <FaWhatsapp className="w-4 h-4 mr-2" />
              WhatsApp
            </Button>
            <Button
              variant="outline"
              onClick={handleEmailShare}
              data-testid="button-share-email"
            >
              <Mail className="w-4 h-4 mr-2" />
              Email
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
